#!/usr/bin/env python3
"""c2g_check.py — check one locally generated reply before anyone relies on it.

Gate G2. Run it on every reply from a local model (see DUAL_MODEL_ROUTING.md
section 5), then do the behaviour test separately, in a sandbox.

What it checks
    1. Leaked control tokens       <|tool_call|>, [TOOL_CALLS], </s>, …
    2. Invisible characters        zero-width spaces, BOMs, soft hyphens
    3. A code fence at all         a reply with no code where code was asked for
    4. Dropped-space signatures    `if[` / `done<` — the mlx-swift-lm 3.31.4 bug
    5. Syntax, and only syntax     ast.parse / bash -n / swiftc -parse

What it does NOT do
    It never executes the reply. ast.parse builds a tree, `bash -n` parses
    without running, `swiftc -parse` stops before codegen. Behaviour testing is
    a separate step and belongs in a sandbox, never against real files. A repair
    is never written back over the input.

Severity
    FAIL       the reply is not usable as delivered (exit 1)
    WARN       usable, but something needs a human eye — every repair this
               script works out is a WARN, never a silent fix
    UNCHECKED  a checker wasn't available, so that block proves nothing (exit 2)

Usage
    c2g_check.py REPLY_FILE [--lang auto|python|bash|swift] [--json]
                 [--write-repaired OUT] [--quiet]
    REPLY_FILE may be '-' to read stdin.

Exit codes
    0  pass (possibly with warnings)
    1  hard fail
    2  a check couldn't run
    3  unreadable input
"""

import argparse
import ast
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

# ── What a leaked chat template looks like ──────────────────────────────────
# Granite and Ministral both occasionally emit their own control tokens inside
# the completion. One of these in the output means the reply is framing, not
# content — `granite__11_json_yaml_v2` in the 2026-10-14 benchmark leaked
# `<|tool_call|>` and was a hard fail for exactly this reason.
CONTROL_TOKENS = [
    "<|tool_call|>", "<|tool_response|>",
    "<|start_of_role|>", "<|end_of_role|>",
    "<|start_of_text|>", "<|end_of_text|>",
    "<|assistant|>", "<|user|>", "<|system|>",
    "<|im_start|>", "<|im_end|>",
    "<|endoftext|>", "<|eot_id|>", "<|start_header_id|>", "<|end_header_id|>",
    "[TOOL_CALLS]", "[AVAILABLE_TOOLS]", "[TOOL_RESULTS]",
    "[INST]", "[/INST]",
    "<s>", "</s>",
]

# ── Characters that are invisible in a terminal and fatal in a source file ──
INVISIBLE = {
    "​": "ZERO WIDTH SPACE",
    "‌": "ZERO WIDTH NON-JOINER",
    "‍": "ZERO WIDTH JOINER",
    "⁠": "WORD JOINER",
    "﻿": "ZERO WIDTH NO-BREAK SPACE (BOM)",
    "­": "SOFT HYPHEN",
    "᠎": "MONGOLIAN VOWEL SEPARATOR",
    "⁡": "FUNCTION APPLICATION",
    "⁢": "INVISIBLE TIMES",
    "⁣": "INVISIBLE SEPARATOR",
    "⁤": "INVISIBLE PLUS",
    " ": "NO-BREAK SPACE",
}

# ── Dropped-space signatures ────────────────────────────────────────────────
# mlx-swift-lm 3.31.4's ToolCallProcessor eats the space BEFORE a potential
# tool-call start character: `[` (bare-JSON mode) and `<` (tagged mode). So
# `if [ -d x ]` arrives as `if[ -d x ]` (measured on Mistral) and `i < n` as
# `i< n` (measured on Granite).
#
# The reliable fingerprint is asymmetry, not a keyword. The bug removes the
# space on the left and leaves the one on the right, and almost nobody writes
# `i< n` or `if[ -f x ]` on purpose — code is either `i < n` or `i<n`. That
# generalises across languages and, unlike a keyword list, it catches the
# Granite form, where the token left of `<` is an ordinary identifier.
#
# The exclusions below are not decoration. Each one is a false positive this
# rule produced against 22 hand-written files in this project, and a WARN
# nobody trusts is worse than no WARN:
#   LEFT_NOT      `(< 10 Hz)` in prose, `<< EOFJSON` heredocs (the second `<`
#                 is preceded by the first), `\[ ... \]` escaped in a comment,
#                 and `[` itself, for bash `[[` (see the token below).
#                 A real dropped space leaves a word character, a closing
#                 bracket or a quote on the left — not an operator or an
#                 opening delimiter.
#   `.` (angle)   `0 ..< 10` — Swift's half-open range, written with spaces
#                 on both sides. Only excluded for `<`, and only alongside
#                 the `..<` token, never on its own.
#   (?<=.)        a line that STARTS with `[` or `<` — `[[ -f x ]] && echo y`
#                 at column 0. There is no space at column 0 for the bug to
#                 have eaten, so an asymmetry there is never this bug.
#   NOT_ESCAPE    `[ \t]`, `[ \d]` — regex character classes, where the space
#                 is part of the class and the next character is a backslash.
#   (?!<)         `cat<<EOF`, legal shell with no space at all.
#
# Known blind spot, worth stating: ` [` eaten before a non-space, e.g.
# `arr [0]` -> `arr[0]`, is indistinguishable from ordinary indexing and
# cannot be detected here. Only the syntax check catches those, and only when
# they break the parse.
_LEFT_CLASS = r"\s<>=!+\-*/\\|&(,{:;%^~?@#$\["
LEFT_NOT = r"(?<=.)(?<![" + _LEFT_CLASS + r"])"
# `.` is excluded on the left of `<` ONLY, for Swift's `..<` — see the
# angle rule below. Widening LEFT_NOT itself would risk a missed `[` bug.
LEFT_NOT_ANGLE = r"(?<=.)(?<![" + _LEFT_CLASS + r".])"
NOT_ESCAPE = r"(?=\s(?!\\))"

ASYMMETRIC_PATTERNS = [
    # The token is `[` or `[[`, and `[` is excluded on the left, so that bash
    # `if [[ "$f" == *.jpeg ]]` stays silent while `if[[ "$f" == ... ]]` — the
    # bug's form of the same line — still fires on the first bracket. Excluding
    # `[` on the left alone would have silenced both: in `if[[`, the bracket
    # followed by a space is the SECOND one, whose left neighbour is a bracket.
    # Measured on mistral__06_bash_rename_v3 in the 2026-11-01 benchmark, where
    # the old rule offered to "repair" working code to `if [ [ "$f" ...`.
    (re.compile(LEFT_NOT + r"(\[\[?)" + NOT_ESCAPE),
     "'[' has a space after it but none before — the space before '[' looks eaten"),
    # Swift's range operators. `0 ..< 10` is legal with symmetric spacing, and
    # the character left of its `<` is a `.`, so `.` is excluded on the left
    # here. But excluding `.` ALONE would also silence the bug form `0..< 10`,
    # whose `<` likewise has a `.` on its left — the identical trap as the
    # `[[` fix above. So `..<` is matched as one token: the match then lands on
    # the FIRST dot, whose left neighbour is the character the eaten space sat
    # beside, and the offered repair inserts the space there (`0 ..< 10`).
    # `x.count< 3` is unaffected either way — the character left of that `<`
    # is `t`, not `.`.
    (re.compile(LEFT_NOT_ANGLE + r"(\.\.<|<=?)(?=\s)"),
     "'<' has a space after it but none before — the space before '<' looks eaten"),
    # The same asymmetry seen from the other side. `var d =[String: String]()`
    # and `-> [T]` written as `->[T]` are the bug with no space left on the
    # right of the bracket, so the two rules above can't see them: the space
    # that survives is the one BEFORE the operator. swiftc reports this as
    # "'=' must have consistent whitespace on both sides" and the model takes
    # the blame — measured on mistral__08_swift_kv, all three variants.
    (re.compile(r"(?<=\s)(?:=|->)(\[)"),
     "'=' or '->' runs straight into '[' while keeping its own leading space "
     "— the space after it looks eaten"),
]

KEYWORDS_BEFORE_BRACKET = [
    # shell
    "if", "elif", "while", "until", "then", "do", "done", "else", "fi",
    "test", "echo", "printf", "read", "cat", "return", "exit",
    # python
    "in", "and", "or", "not", "is", "assert", "yield", "lambda", "for",
    "del", "print",
    # swift
    "guard", "let", "var", "func", "case", "default",
]
KEYWORDS_BEFORE_ANGLE = [
    "if", "elif", "while", "until", "return", "assert", "and", "or", "not",
    "in", "is", "guard", "else", "do", "done", "read", "cat", "then",
    "let", "var", "case", "print", "echo", "printf", "test",
]

KEYWORD_PATTERNS = [
    (re.compile(r"\b(%s)(\[)" % "|".join(sorted(set(KEYWORDS_BEFORE_BRACKET)))),
     "keyword runs straight into '[' — the space before '[' looks eaten"),
    (re.compile(r"\b(%s)(<)(?!<)" % "|".join(sorted(set(KEYWORDS_BEFORE_ANGLE)))),
     "keyword runs straight into '<' — the space before '<' looks eaten"),
]

FENCE_RE = re.compile(
    r"^[ \t]*```[ \t]*([A-Za-z0-9_+#.-]*)[ \t]*\r?\n(.*?)^[ \t]*```",
    re.DOTALL | re.MULTILINE,
)
OPEN_FENCE_RE = re.compile(r"^[ \t]*```[ \t]*([A-Za-z0-9_+#.-]*)[ \t]*\r?\n", re.MULTILINE)

LANG_ALIASES = {
    "py": "python", "python3": "python", "python": "python",
    "sh": "bash", "shell": "bash", "bash": "bash", "zsh": "bash",
    "swift": "swift",
    "json": "json",
    "yaml": "yaml", "yml": "yaml",
}

# A line has to look at least a little like code before "no code fence" is
# downgraded from a hard fail to a warning.
CODE_LIKE_RE = re.compile(
    r"(^\s*(def|class|function|import|from|let|var|func|if|for|while|return|echo|print)\b"
    r"|^#!|[=;{}]|\(\s*\))"
)

# A bare YAML mapping is code, but it carries none of the markers above: no
# `=`, no braces, no keyword, no call. `--lang yaml` on an unfenced reply
# therefore hard-failed valid YAML — four of the six 11_json_yaml replies in
# the 2026-11-01 benchmark, every one of which the benchmark itself scored
# yaml_equal=pass. Gated on the language below rather than folded into
# CODE_LIKE_RE, because `Note: see below` in a prose reply must not count as
# code and `--lang auto` must stay free to say "this is prose, and that's fine".
YAML_LIKE_RE = re.compile(r"^\s*(-\s+)?[A-Za-z_][\w.-]*\s*:(\s|$)")


class Finding(object):
    def __init__(self, severity, code, message, line=None, detail=None):
        self.severity = severity      # FAIL | WARN | UNCHECKED | INFO
        self.code = code
        self.message = message
        self.line = line
        self.detail = detail

    def render(self):
        where = " line %d" % self.line if self.line else ""
        out = "  %-9s %-18s%s %s" % (self.severity, self.code, where, self.message)
        if self.detail:
            out += "\n            | " + "\n            | ".join(self.detail.split("\n"))
        return out

    def as_dict(self):
        return {"severity": self.severity, "code": self.code,
                "message": self.message, "line": self.line}


def read_input(path):
    """Return text, or exit 3. A decode failure is a real result, not noise:
    a reply that isn't valid UTF-8 has been mangled somewhere upstream."""
    try:
        if path == "-":
            raw = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as fh:
                raw = fh.read()
    except OSError as exc:
        sys.stderr.write("  UNREADABLE  %s\n" % exc)
        sys.exit(3)
    if not raw.strip():
        sys.stderr.write("  UNREADABLE  input is empty\n")
        sys.exit(3)
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        sys.stderr.write("  UNREADABLE  input is not valid UTF-8: %s\n" % exc)
        sys.exit(3)


def line_of(text, index):
    return text.count("\n", 0, index) + 1


def check_control_tokens(text, findings):
    for token in CONTROL_TOKENS:
        start = text.find(token)
        if start != -1:
            findings.append(Finding(
                "FAIL", "control-token",
                "leaked chat-template token %r" % token,
                line=line_of(text, start),
                detail=text.split("\n")[line_of(text, start) - 1].strip()[:160],
            ))


def check_invisible(text, findings):
    for ch, name in INVISIBLE.items():
        start = text.find(ch)
        if start != -1:
            count = text.count(ch)
            findings.append(Finding(
                "FAIL", "invisible-char",
                "%s (U+%04X) x%d" % (name, ord(ch), count),
                line=line_of(text, start),
            ))


FENCE_LINE_RE = re.compile(r"^[ \t]*```[ \t]*[A-Za-z0-9_+#.-]*[ \t]*$")


def strip_stray_fences(text, findings):
    """Drop an unmatched fence line that brackets an otherwise fine reply.

    Models routinely emit the closing ``` and forget the opening one. The code
    between them is usually perfect, and feeding the stray line to a parser
    turns a good reply into a SyntaxError on the last line — the exact
    "generated code never got a fair run" trap SKILL-MLX.md's Step 6 warns
    about, which for nine days made every smoke test look like a model
    failure. Returns (text, had_opening_fence)."""
    lines = text.split("\n")
    fence_idx = [i for i, l in enumerate(lines) if FENCE_LINE_RE.match(l)]
    if not fence_idx:
        return text, False

    non_empty = [i for i, l in enumerate(lines) if l.strip()]
    first_real = non_empty[0] if non_empty else 0

    # A single fence line at the very top is an OPENING fence whose partner
    # never arrived: that is a truncated reply, not a stray, and the caller
    # handles it differently.
    if len(fence_idx) == 1 and fence_idx[0] <= first_real:
        return text, True

    kept = [l for i, l in enumerate(lines) if i not in set(fence_idx)]
    findings.append(Finding(
        "WARN", "stray-fence",
        "%d unmatched fence line(s) removed before checking — the model opened "
        "or closed a fence it didn't finish" % len(fence_idx),
        line=fence_idx[0] + 1))
    return "\n".join(kept), False


def extract_blocks(text, forced_lang, findings):
    """Return [(lang, code, first_line, from_fence)]. Reports the fence problems the
    paired-run prompt cares about: no fence, more than one, prose alongside."""
    blocks = []
    for match in FENCE_RE.finditer(text):
        tag = (match.group(1) or "").lower()
        lang = LANG_ALIASES.get(tag, tag or (forced_lang if forced_lang != "auto" else ""))
        blocks.append((lang, match.group(2), line_of(text, match.start(2)), True))

    if len(blocks) > 1:
        findings.append(Finding(
            "WARN", "multiple-fences",
            "%d code fences; the paired-run prompt asks for exactly one" % len(blocks)))

    if blocks:
        outside = FENCE_RE.sub("", text).strip()
        if len(outside.split()) > 12:
            findings.append(Finding(
                "WARN", "prose-outside-fence",
                "%d words of text outside the code fence" % len(outside.split())))
        return blocks

    # No matched pair. Deal with the stray-fence case before anything else, so
    # a good reply isn't condemned by a leftover ``` line.
    body, opening_fence = strip_stray_fences(text, findings)

    if opening_fence:
        open_match = OPEN_FENCE_RE.search(text)
        if open_match:
            tag = (open_match.group(1) or "").lower()
            lang = LANG_ALIASES.get(tag, tag or (forced_lang if forced_lang != "auto" else ""))
            findings.append(Finding(
                "WARN", "unterminated-fence",
                "a fence opens and never closes — reply looks truncated",
                line=line_of(text, open_match.start())))
            return [(lang, text[open_match.end():], line_of(text, open_match.end()), True)]

    code_like = sum(1 for line in body.split("\n") if CODE_LIKE_RE.search(line))
    if code_like == 0 and forced_lang == "yaml":
        code_like = sum(1 for line in body.split("\n") if YAML_LIKE_RE.search(line))
    if code_like == 0:
        # Hard-fail only if code was asked for. `--lang auto` on a prose task
        # (the benchmark's 12_bullets family) must not be a failure: there is
        # nothing wrong with a text answer to a text question.
        if forced_lang != "auto":
            findings.append(Finding(
                "FAIL", "no-code",
                "no code fence and nothing that looks like code, but --lang %s "
                "says code was expected" % forced_lang,
                detail=" ".join(body.split())[:200]))
        else:
            findings.append(Finding(
                "WARN", "no-code",
                "no code in this reply — fine for a prose task, wrong for "
                "anything else",
                detail=" ".join(body.split())[:200]))
        return []

    findings.append(Finding(
        "WARN", "no-fence",
        "no code fence; treating the whole reply as %s"
        % (forced_lang if forced_lang != "auto" else "code")))
    return [(forced_lang if forced_lang != "auto" else "", body, 1, False)]


def check_dropped_spaces(code, first_line, findings):
    """Report signatures and the repair, never apply it silently.
    Returns the repaired text, used only for the follow-up syntax check."""
    repaired_lines = []
    for offset, line in enumerate(code.split("\n")):
        hits = {}        # column -> why, so the two families can't double-report

        for pattern, why in ASYMMETRIC_PATTERNS:
            for match in pattern.finditer(line):
                hits[match.start(1)] = why
        for pattern, why in KEYWORD_PATTERNS:
            for match in pattern.finditer(line):
                hits.setdefault(match.start(2), why)

        for column in sorted(hits):
            findings.append(Finding(
                "WARN", "dropped-space", hits[column],
                line=first_line + offset,
                detail="as delivered: %s" % line.strip()[:160]))

        if hits:
            fixed = line
            for column in sorted(hits, reverse=True):
                fixed = fixed[:column] + " " + fixed[column:]
            findings.append(Finding(
                "WARN", "repair-available",
                "%d space(s) would be inserted on this line" % len(hits),
                line=first_line + offset,
                detail="repaired:     %s" % fixed.strip()[:160]))
        else:
            fixed = line
        repaired_lines.append(fixed)
    return "\n".join(repaired_lines)


def guess_lang(code, forced):
    if forced and forced != "auto":
        return forced
    if re.search(r"^\s*(def|class)\s+\w+|^\s*import\s+\w+|^\s*from\s+\w+\s+import", code, re.M):
        return "python"
    if re.search(r"^#!.*\b(ba|z|)sh\b|^\s*(fi|esac|done)\s*$|\$\{\w+|\[\[ ", code, re.M):
        return "bash"
    if re.search(r"^\s*(func|let|var|guard|import Foundation)\b", code, re.M):
        return "swift"
    return ""


def syntax_python(code, first_line, findings):
    try:
        ast.parse(code)
    except SyntaxError as exc:
        findings.append(Finding(
            "FAIL", "syntax", "python: %s" % (exc.msg,),
            line=first_line + (exc.lineno or 1) - 1,
            detail=(exc.text or "").rstrip()[:160]))
        return False
    except ValueError as exc:            # e.g. a null byte in the source
        findings.append(Finding("FAIL", "syntax", "python: %s" % exc))
        return False
    return True


def _run_parser(argv, code, suffix):
    """Write the code to a temp file and parse it. Returns (rc, stderr) or
    (None, reason) when the tool couldn't run at all."""
    tool = argv[0]
    if shutil.which(tool) is None:
        return None, "%s is not on PATH" % tool
    fd, path = tempfile.mkstemp(suffix=suffix, prefix="c2g_check_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(code if code.endswith("\n") else code + "\n")
        try:
            proc = subprocess.run(argv + [path], capture_output=True, text=True, timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            return None, "%s couldn't run: %s" % (tool, exc)
        err = (proc.stderr or "") + (proc.stdout or "")
        # A Mac that hasn't accepted the Xcode licence fails every xcrun tool
        # with this, exit 69. That is NOT a syntax error, and calling it one
        # would condemn perfectly good code.
        if "agreed to the Xcode" in err or "xcode-select" in err and proc.returncode == 69:
            return None, ("%s can't run until the Xcode licence is accepted "
                          "(sudo xcodebuild -license)" % tool)
        if "no such module" in err.lower() or "cannot find" in err.lower() and proc.returncode != 0:
            # Leave module resolution to the real build; -parse shouldn't need it.
            pass
        return proc.returncode, err
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def syntax_bash(code, first_line, findings):
    rc, err = _run_parser(["bash", "-n"], code, ".sh")
    if rc is None:
        findings.append(Finding("UNCHECKED", "no-checker", err))
        return None
    if rc != 0:
        findings.append(Finding(
            "FAIL", "syntax", "bash -n rejected it",
            detail="\n".join(err.strip().split("\n")[:4])[:400]))
        return False
    return True


def syntax_swift(code, first_line, findings):
    rc, err = _run_parser(["swiftc", "-parse"], code, ".swift")
    if rc is None:
        findings.append(Finding("UNCHECKED", "no-checker", err))
        return None
    if rc != 0:
        findings.append(Finding(
            "FAIL", "syntax", "swiftc -parse rejected it",
            detail="\n".join(err.strip().split("\n")[:4])[:400]))
        return False
    return True


def syntax_json(code, first_line, findings):
    try:
        json.loads(code)
    except ValueError as exc:
        findings.append(Finding(
            "FAIL", "syntax", "json: %s" % exc, line=first_line))
        return False
    return True


def syntax_yaml(code, first_line, findings):
    # PyYAML isn't a dependency of this project, so its absence is UNCHECKED,
    # not a failure. safe_load, never load: a YAML tag can otherwise construct
    # arbitrary Python objects, and this script must not run the reply.
    try:
        import yaml
    except ImportError:
        findings.append(Finding(
            "UNCHECKED", "no-checker",
            "PyYAML isn't installed, so the YAML wasn't parsed"))
        return None
    try:
        yaml.safe_load(code)
    except Exception as exc:
        findings.append(Finding(
            "FAIL", "syntax", "yaml: %s" % str(exc).split("\n")[0], line=first_line))
        return False
    return True


SYNTAX_CHECKERS = {"python": syntax_python, "bash": syntax_bash,
                   "swift": syntax_swift, "json": syntax_json,
                   "yaml": syntax_yaml}


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="c2g_check.py",
        description="Syntax and hygiene check for one locally generated reply. "
                    "Never executes the reply.")
    parser.add_argument("reply", help="file holding the reply, or '-' for stdin")
    parser.add_argument("--lang", default="auto",
                        choices=["auto", "python", "bash", "swift",
                                 "json", "yaml"],
                        help="language to assume when the fence doesn't say")
    parser.add_argument("--json", action="store_true",
                        help="machine-readable summary on stdout (for the ledger)")
    parser.add_argument("--write-repaired", metavar="OUT",
                        help="write the dropped-space repair here (never over the input)")
    parser.add_argument("--quiet", action="store_true",
                        help="print the verdict line only")
    args = parser.parse_args(argv)

    text = read_input(args.reply)
    findings = []

    check_control_tokens(text, findings)
    check_invisible(text, findings)
    blocks = extract_blocks(text, args.lang, findings)

    repaired_blocks = []
    checked_langs = []
    for lang, code, first_line, from_fence in blocks:
        lang = LANG_ALIASES.get(lang, lang) or guess_lang(code, args.lang)
        repaired = check_dropped_spaces(code, first_line, findings)
        repaired_blocks.append(repaired)

        checker = SYNTAX_CHECKERS.get(lang)
        if checker is None:
            if from_fence:
                # A fenced block is code the model meant as code. Not being
                # able to parse it is a real gap, so it counts as unchecked.
                findings.append(Finding(
                    "UNCHECKED", "unknown-lang",
                    "can't tell what language this fenced block is; no syntax "
                    "check run", line=first_line))
            else:
                # No fence, no recognisable language, and the caller didn't say
                # code was expected — a prose answer to a prose task. Nothing
                # was due, so this is not an unchecked check.
                findings.append(Finding(
                    "WARN", "nothing-to-check",
                    "no fence and no recognisable language; nothing was "
                    "syntax-checked", line=first_line))
            continue
        checked_langs.append(lang)
        ok = checker(code, first_line, findings)
        # If the code as delivered is broken but the repaired form parses, the
        # dropped-space bug is the whole story. Worth saying plainly — it's the
        # difference between "this model can't write bash" and "this build
        # eats spaces".
        if ok is False and repaired != code:
            again = []
            if checker(repaired, first_line, again) is True:
                findings.append(Finding(
                    "WARN", "repair-fixes-syntax",
                    "the repaired form parses cleanly — this is the "
                    "dropped-space bug, not a logic error"))

    if args.write_repaired and repaired_blocks:
        try:
            with open(args.write_repaired, "w", encoding="utf-8") as fh:
                fh.write("\n\n".join(repaired_blocks))
        except OSError as exc:
            findings.append(Finding("WARN", "write-failed", str(exc)))

    fails = [f for f in findings if f.severity == "FAIL"]
    unchecked = [f for f in findings if f.severity == "UNCHECKED"]
    warns = [f for f in findings if f.severity == "WARN"]

    if fails:
        verdict, code = "FAIL", 1
    elif unchecked:
        verdict, code = "UNCHECKED", 2
    else:
        verdict, code = "PASS", 0

    if args.json:
        print(json.dumps({
            "reply": args.reply,
            "verdict": verdict,
            "check": {"PASS": "pass", "FAIL": "fail",
                      "UNCHECKED": "na"}[verdict],
            "exit": code,
            "blocks": len(blocks),
            "langs": checked_langs,
            "chars": len(text),
            "fails": [f.as_dict() for f in fails],
            "warnings": [f.as_dict() for f in warns],
            "unchecked": [f.as_dict() for f in unchecked],
        }, indent=2))
        return code

    if not args.quiet:
        print("  %s" % args.reply)
        for finding in findings:
            print(finding.render())
        if not findings:
            print("  clean — no findings")
    print("  verdict: %s  (%d fail, %d warn, %d unchecked)"
          % (verdict, len(fails), len(warns), len(unchecked)))
    return code


if __name__ == "__main__":
    sys.exit(main())
